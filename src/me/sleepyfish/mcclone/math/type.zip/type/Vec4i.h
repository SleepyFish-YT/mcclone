//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC4I_H
#define MCCLONE_VEC4I_H

/**
 * @author SleepyFish
 * @brief This struct represents a 4D int vector
 */
struct Vec4i {
    int x = 0;
    int y = 0;
    int z = 0;
    int w = 0;

    Vec4i operator+(const Vec4i& other) const {
        return Vec4i(this->x + other.x, this->y + other.y, this->z + other.z, this->w + other.w);
    }

    Vec4i operator-(const Vec4i& other) const {
        return Vec4i(this->x - other.x, this->y - other.y, this->z - other.z, this->w - other.w);
    }

    Vec4i operator*(const int& other) const {
        return Vec4i(this->x * other, this->y * other, this->z * other, this->w * other);
    }

    Vec4i operator/(const int& other) const {
        return Vec4i(this->x / other, this->y / other, this->z / other, this->w / other);
    }

    bool operator==(const Vec4i& other) const {
        return this->x == other.x && this->y == other.y && this->z == other.z && this->w == other.w;
    }
};

#endif //MCCLONE_VEC4I_H
