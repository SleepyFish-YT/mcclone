//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC2F_H
#define MCCLONE_VEC2F_H

/**
 * @author SleepyFish
 * @brief This struct represents a 2D float vector
 */
struct Vec2f {
    float x = 0.0f;
    float y = 0.0f;

    Vec2f operator+(const Vec2f& other) const {
        return Vec2f(this->x + other.x, this->y + other.y);
    }

    Vec2f operator-(const Vec2f& other) const {
        return Vec2f(this->x - other.x, this->y - other.y);
    }

    Vec2f operator*(const float& other) const {
        return Vec2f(this->x * other, this->y * other);
    }

    Vec2f operator/(const float& other) const {
        return Vec2f(this->x / other, this->y / other);
    }

    bool operator==(const Vec2f& other) const {
        return this->x == other.x && this->y == other.y;
    }
};

#endif //MCCLONE_VEC2F_H
