//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC4F_H
#define MCCLONE_VEC4F_H

/**
 * @author SleepyFish
 * @brief This struct represents a 4D float vector
 */
struct Vec4f {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
    float w = 0.0f;

    Vec4f operator+(const Vec4f& other) const {
        return Vec4f(this->x + other.x, this->y + other.y, this->z + other.z, this->w + other.w);
    }

    Vec4f operator-(const Vec4f& other) const {
        return Vec4f(this->x - other.x, this->y - other.y, this->z - other.z, this->w - other.w);
    }

    Vec4f operator*(const float& other) const {
        return Vec4f(this->x * other, this->y * other, this->z * other, this->w * other);
    }

    Vec4f operator/(const float& other) const {
        return Vec4f(this->x / other, this->y / other, this->z / other, this->w / other);
    }

    bool operator==(const Vec4f& other) const {
        return this->x == other.x && this->y == other.y && this->z == other.z && this->w == other.w;
    }
};

#endif //MCCLONE_VEC4F_H
