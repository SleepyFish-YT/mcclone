//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC3F_H
#define MCCLONE_VEC3F_H

/**
 * @author SleepyFish
 * @brief This struct represents a 3D float vector
 */
struct Vec3f {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;

    Vec3f operator+(const Vec3f& other) const {
        return Vec3f(this->x + other.x, this->y + other.y, this->z + other.z);
    }

    Vec3f operator-(const Vec3f& other) const {
        return Vec3f(this->x - other.x, this->y - other.y, this->z - other.z);
    }

    Vec3f operator*(const float& other) const {
        return Vec3f(this->x * other, this->y * other, this->z * other);
    }

    Vec3f operator/(const float& other) const {
        return Vec3f(this->x / other, this->y / other, this->z / other);
    }

    bool operator==(const Vec3f& other) const {
        return this->x == other.x && this->y == other.y && this->z == other.z;
    }
};

#endif //MCCLONE_VEC3F_H
