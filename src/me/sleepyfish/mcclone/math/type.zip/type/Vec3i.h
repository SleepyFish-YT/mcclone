//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC3I_H
#define MCCLONE_VEC3I_H

/**
 * @author SleepyFish
 * @brief This struct represents a 3D int vector
 */
struct Vec3i {
    int x = 0;
    int y = 0;
    int z = 0;

    Vec3i operator+(const Vec3i& other) const {
        return Vec3i(this->x + other.x, this->y + other.y, this->z + other.z);
    }

    Vec3i operator-(const Vec3i& other) const {
        return Vec3i(this->x - other.x, this->y - other.y, this->z - other.z);
    }

    Vec3i operator*(const int& other) const {
        return Vec3i(this->x * other, this->y * other, this->z * other);
    }

    Vec3i operator/(const int& other) const {
        return Vec3i(this->x / other, this->y / other, this->z / other);
    }

    bool operator==(const Vec3i& other) const {
        return this->x == other.x && this->y == other.y && this->z == other.z;
    }
};

#endif //MCCLONE_VEC3I_H
