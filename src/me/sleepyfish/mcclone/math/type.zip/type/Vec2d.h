//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC2D_H
#define MCCLONE_VEC2D_H

/**
 * @author SleepyFish
 * @brief This struct represents a 2D double vector
 */
struct Vec2d {
    double x = 0.0;
    double y = 0.0;

    Vec2d operator+(const Vec2d& other) const {
        return Vec2d(this->x + other.x, this->y + other.y);
    }

    Vec2d operator-(const Vec2d& other) const {
        return Vec2d(this->x - other.x, this->y - other.y);
    }

    Vec2d operator*(const double& other) const {
        return Vec2d(this->x * other, this->y * other);
    }

    Vec2d operator/(const double& other) const {
        return Vec2d(this->x / other, this->y / other);
    }

    bool operator==(const Vec2d& other) const {
        return this->x == other.x && this->y == other.y;
    }
};

#endif //MCCLONE_VEC2D_H
