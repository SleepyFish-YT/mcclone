//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC4D_H
#define MCCLONE_VEC4D_H

/**
 * @author SleepyFish
 * @brief This struct represents a 4D double vector
 */
struct Vec4d {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
    double w = 0.0;

    Vec4d operator+(const Vec4d& other) const {
        return Vec4d(this->x + other.x, this->y + other.y, this->z + other.z, this->w + other.w);
    }

    Vec4d operator-(const Vec4d& other) const {
        return Vec4d(this->x - other.x, this->y - other.y, this->z - other.z, this->w - other.w);
    }

    Vec4d operator*(const double& other) const {
        return Vec4d(this->x * other, this->y * other, this->z * other, this->w * other);
    }

    Vec4d operator/(const double& other) const {
        return Vec4d(this->x / other, this->y / other, this->z / other, this->w / other);
    }

    bool operator==(const Vec4d& other) const {
        return this->x == other.x && this->y == other.y && this->z == other.z && this->w == other.w;
    }
};

#endif //MCCLONE_VEC4D_H
