//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC2I_H
#define MCCLONE_VEC2I_H

/**
 * @author SleepyFish
 * @brief This struct represents a 2D integer vector
 */
struct Vec2i {
    int x = 0;
    int y = 0;

    Vec2i operator+(const Vec2i& other) const {
        return Vec2i(this->x + other.x, this->y + other.y);
    }

    Vec2i operator-(const Vec2i& other) const {
        return Vec2i(this->x - other.x, this->y - other.y);
    }

    Vec2i operator*(const int& other) const {
        return Vec2i(this->x * other, this->y * other);
    }

    Vec2i operator/(const int& other) const {
        return Vec2i(this->x / other, this->y / other);
    }

    bool operator==(const Vec2i& other) const {
        return this->x == other.x && this->y == other.y;
    }
};

#endif //MCCLONE_VEC2I_H
