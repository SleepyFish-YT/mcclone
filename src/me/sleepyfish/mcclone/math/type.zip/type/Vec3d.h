//
// Created by SleepyFish on 05.06.2026.
// Project: mcclone
//

#ifndef MCCLONE_VEC3D_H
#define MCCLONE_VEC3D_H

/**
 * @author SleepyFish
 * @brief This struct represents a 3D double vector
 */
struct Vec3d {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;

    Vec3d operator+(const Vec3d& other) const {
        return Vec3d(this->x + other.x, this->y + other.y, this->z + other.z);
    }

    Vec3d operator-(const Vec3d& other) const {
        return Vec3d(this->x - other.x, this->y - other.y, this->z - other.z);
    }

    Vec3d operator*(const double& other) const {
        return Vec3d(this->x * other, this->y * other, this->z * other);
    }

    Vec3d operator/(const double& other) const {
        return Vec3d(this->x / other, this->y / other, this->z / other);
    }

    bool operator==(const Vec3d& other) const {
        return this->x == other.x && this->y == other.y && this->z == other.z;
    }
};

#endif //MCCLONE_VEC3D_H
